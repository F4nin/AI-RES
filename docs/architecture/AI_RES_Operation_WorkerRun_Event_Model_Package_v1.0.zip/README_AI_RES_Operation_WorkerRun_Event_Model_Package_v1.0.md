# AI RES — Operation & WorkerRun Event Model Package v1.0

Пакет фиксирует нормативную модель доменных событий Operation и WorkerRun.

Состав:
- AI_RES_Operation_WorkerRun_Event_Model_v1.0.md
- AI_RES_Operation_and_Readiness_Gate_Architecture_Decision_v1.3.md
- AI_RES_Domain_Model_and_Data_Architecture_v1.5.md
- AI_RES_Process_Design_and_Algorithms_v1.5.md
- AI_RES_API_and_Interaction_Contracts_v1.6.md
- AI_RES_Domain_Events_AsyncAPI_v1.5.yaml
- AI_RES_Operation_and_Readiness_Gate_State_Machine_v1.2.json
- AI_RES_Claude_Code_Implementation_Spec_v1.16.md
- AI_RES_Document_Registry_v3.5.md
- AI_RES_Operation_WorkerRun_Event_Model_Verification_v1.0.md
- SHA256SUMS manifest

Доставка: at-least-once; ordering: per aggregate only; deduplication: consumer Inbox. Exactly-once не обещается. Статические проверки не подтверждают runtime correctness.

# AI RES PostgreSQL Migration & Access Package v1.0

Пакет фиксирует выбранную стратегию Alembic migrations и PostgreSQL access model для AI RES.

## Содержимое

- `AI_RES_PostgreSQL_Migration_and_Access_Strategy_v1.0.md` — нормативная стратегия, роли, RLS, migration runbook и acceptance criteria.
- `AI_RES_PostgreSQL_Roles_RLS_v1.0.sql` — SQL reference template ролей, GRANT и RLS.
- `AI_RES_PostgreSQL_Migration_Access_Verification_v1.0.md` — результаты статической проверки и ограничения.
- Актуальные связанные Domain Model, Process Design, API, Identity, Infrastructure, Architecture Decision, Event Model, PostgreSQL Physical Model, Implementation Spec и Document Registry.

## Важно

SQL — шаблон для адаптации к фактической схеме. Он не был выполнен на PostgreSQL. Alembic environment, реальные роли, политики, миграции и runtime tests ещё не реализованы. Не использовать как production-ready SQL без schema reconnaissance, security review и migration rehearsals.

# AI RES — PostgreSQL Physical Model Package v1.0

Дата: 10.11.2026

Пакет содержит нормативную физическую модель execution persistence slice AI RES и сопутствующие контракты.

## Состав
- PostgreSQL Physical Model and Transactions v1.0 — таблицы, связи, индексы, транзакции TX-01..TX-09, migration/recovery rules.
- PostgreSQL Physical Model SQL v1.0 — проектный DDL slice; требует expand/backfill/contract и адаптации к текущим migrations.
- PostgreSQL Verification v1.0 — статическая проверка и ограничения доказательности.
- Architecture Decision v1.4, Domain Model v1.6, Process Design v1.6, Event Model v1.1, Implementation Spec v1.17, Registry v3.6.
- AsyncAPI v1.5 и State Machine JSON v1.2 как связанные контракты.

## Важное ограничение
SQL не запускался на PostgreSQL и не является готовой production migration. Перед применением необходимо сверить фактическую схему `work.tasks`, выполнить approved backfill `operation_id`, разбить DDL на версионированные миграции и пройти integration/security tests.

ZIP — транспортный снимок. Нормативная актуальность определяется Document Registry v3.6.

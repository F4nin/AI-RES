-- Run as controlled deployment operator; read-only preflight.
SELECT current_setting('server_version') AS server_version;
SELECT current_database() AS database_name, current_user AS executing_role;
SELECT schemaname, tablename FROM pg_tables
 WHERE schemaname IN ('operations','work','agents','execution','audit','platform')
 ORDER BY schemaname, tablename;
SELECT pid, usename, state, wait_event_type, wait_event, now()-xact_start AS xact_age, query
  FROM pg_stat_activity WHERE datname=current_database() AND xact_start IS NOT NULL
 ORDER BY xact_start;
SELECT n.nspname AS schema_name, c.relname AS table_name, i.relname AS index_name
  FROM pg_index x JOIN pg_class c ON c.oid=x.indrelid
  JOIN pg_class i ON i.oid=x.indexrelid JOIN pg_namespace n ON n.oid=c.relnamespace
 WHERE n.nspname IN ('operations','work','agents','execution','audit','platform')
   AND NOT x.indisvalid;

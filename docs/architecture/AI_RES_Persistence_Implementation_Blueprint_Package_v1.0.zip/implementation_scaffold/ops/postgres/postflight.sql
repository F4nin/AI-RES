-- Run after migration using a read-only verification identity.
SELECT version_num FROM platform.alembic_version;
SELECT connamespace::regnamespace AS schema_name, conrelid::regclass AS table_name, conname, convalidated
  FROM pg_constraint WHERE connamespace::regnamespace::text IN ('operations','work','agents','execution','audit','platform')
 ORDER BY 1,2,3;
SELECT schemaname, tablename, rowsecurity, forcerowsecurity
  FROM pg_tables t JOIN pg_class c ON c.relname=t.tablename
  JOIN pg_namespace n ON n.nspname=t.schemaname AND n.oid=c.relnamespace
 WHERE t.schemaname IN ('operations','work','agents','execution','audit','platform');

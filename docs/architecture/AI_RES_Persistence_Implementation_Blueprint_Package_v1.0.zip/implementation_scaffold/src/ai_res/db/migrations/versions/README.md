# Migration revision plan

Create immutable revisions in the sequence defined by Persistence Blueprint §5. Do not apply the template placeholders as production migrations. The current design DDL is not a substitute for repository-aware revisions: first inspect existing metadata/schema and reconcile all legacy objects. Single Alembic head is required.

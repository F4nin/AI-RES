"""Alembic environment template for AI RES; wire metadata imports in repository."""
from __future__ import annotations
import os
from logging.config import fileConfig
from alembic import context
from sqlalchemy import engine_from_config, pool

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# TODO: import Base and every model module so metadata is complete.
# from ai_res.db.base import Base
target_metadata = None  # Replace with Base.metadata before enabling autogenerate.
SCHEMA_ALLOWLIST = {"operations", "work", "agents", "execution", "audit", "platform"}

url = os.environ.get("AI_RES_MIGRATION_DATABASE_URL")
if not url:
    raise RuntimeError("AI_RES_MIGRATION_DATABASE_URL is required; never store DSN in alembic.ini")
config.set_main_option("sqlalchemy.url", url.replace("%", "%%"))

def include_name(name, type_, parent_names):
    if type_ == "schema":
        return name in SCHEMA_ALLOWLIST
    schema = parent_names.get("schema_name")
    if schema is not None and schema not in SCHEMA_ALLOWLIST:
        return False
    return True

def run_migrations_offline():
    context.configure(
        url=url, target_metadata=target_metadata, literal_binds=True,
        dialect_opts={"paramstyle": "named"}, include_schemas=True,
        include_name=include_name, version_table_schema="platform",
        compare_type=True, compare_server_default=False,
    )
    with context.begin_transaction():
        context.run_migrations()

def run_migrations_online():
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}), prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        connection.exec_driver_sql("SET lock_timeout = '5s'")
        connection.exec_driver_sql("SET statement_timeout = '15min'")
        context.configure(
            connection=connection, target_metadata=target_metadata,
            include_schemas=True, include_name=include_name,
            version_table_schema="platform", compare_type=True,
            compare_server_default=False, transaction_per_migration=True,
        )
        with context.begin_transaction():
            context.run_migrations()

if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()

# PostgreSQL integration test contract

Run against the same PostgreSQL major as deployment, using provisioned non-owner roles. Required cases are PERSIST-001..024 in `AI_RES_Persistence_Implementation_Blueprint_v1.0.md`. SQLite is not an acceptable substitute for RLS, lock, concurrent sequence, index, or migration tests. Test fixtures must create separate organization/project scopes and verify default-deny with no tenant context.
